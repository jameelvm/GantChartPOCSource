import { Injectable } from '@angular/core';
import {Task} from "./task";
import { TaskCount } from './taskcount';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  get(): Promise<Task[]>{
    return Promise.resolve([
      {id: 1, text: "Priliminary Activities", start_date: "2017-08-01 00:00", end_date: "2017-08-15 00:00"},
      {id: 2, text: "Audit Planning", start_date: "2017-08-01 00:00", end_date: "2017-08-15 00:00",parent: 1},
      {id: 17, text: "Pre-Engagement", start_date: "2017-08-01 00:00", end_date: "2017-08-08 00:00",parent: 2},
      {id: 18, text: "Strategy", start_date: "2017-08-10 00:00", end_date: "2017-08-15 00:00",parent: 2},
      {id: 19, text: "Audit plan", start_date: "2017-08-10 00:00", end_date: "2017-08-15 00:00",parent: 2},
      {id: 3, text: "Independance", start_date: "2017-08-03 00:00", end_date: "2017-08-04",parent: 1},
      {id: 4, text: "Risk Assessment", start_date: "2017-08-04 00:00",end_date: "2017-08-05"},
      {id: 5, text: "Components of Internal", start_date: "2017-08-03 00:00", end_date: "2017-08-04",parent: 4},
      {id: 6, text: "Materiality", start_date: "2017-08-05 00:00", end_date: "2017-08-06",parent: 4},
      {id: 7, text: "Risk Assessment", start_date: "2017-08-03 00:00", end_date: "2017-08-05",parent: 4},
      {id: 8, text: "Planning", start_date: "2017-08-02 00:00", end_date: "2017-08-04", type: 1},
      {id: 9, text: "Audit Planning", start_date: "2017-08-01 00:00", end_date: "2017-08-02",parent:8, type: 1},
      {id: 10, text: "Inetrim Responds", start_date: "2017-08-02 00:00", end_date: "2017-08-03", type: 1},
      {id: 11, text: "Risk Assessment", start_date: "2017-08-03 00:00", end_date: "2017-08-04",parent: 10, type: 1},
      {id: 12, text: "Assessment", start_date: "2017-08-01 01:00", end_date: "2017-08-13",parent: 10, type: 1},
      {id: 13, text: "Final Response", start_date: "2017-08-02 00:00", end_date: "2017-08-03", type: 1},
      {id: 14, text: "Audit Planning", start_date: "2017-08-03 00:00", end_date: "2017-08-04",parent: 13, type: 1},
      {id: 15, text: "Risk Assessment", start_date: "2017-08-04 00:00", end_date: "2017-08-05",parent: 13, type: 1},
      {id: 16, text: "Completion", start_date: "2017-08-05 00:00", end_date: "2017-08-06", type: 1},
    ]as Task[]);
}

getTaskCount(): Promise<TaskCount[]>{
  return Promise.resolve([
    {id: 2,  end_date: "2017-08-08 00:00",childCount:1},
    {id: 2,  end_date: "2017-08-15 00:00",childCount:2},
  ]as TaskCount[]);
}

getData(){
 let tasks_ = [
     {id: 1, title: "Priliminary Activities", start_date: "2017-08-01 00:00", end_date: "2017-08-30", progress: 0.6},
    {id: 2, title: "Audit Planning", start_date: "2017-08-18 00:00", duration: 3, parent: 1,progress: 0.4, type: 1},
    {id: 3, title: "Inetrim Responds", start_date: "2017-08-20 00:00", end_date: "2017-08-21", parent: 1, progress: 0.3},
    {id: 4, title: "Planning", start_date: "2017-08-18 00:00", duration: 23, progress: 0.4},
    {id: 5, title: "Audit Planning", start_date: "2017-08-15 00:00", end_date: "2017-08-30",parent: 4, progress: 0},
    {id: 6, title: "Final Response", start_date: "2017-08-15 00:00", end_date: "2017-08-21", progress: 0},
    {id: 7, title: "Risk Assessment", start_date: "2017-08-21 00:00", end_date: "2017-08-30",parent: 6, progress: 0},
    {id: 8, title: "Completion", start_date: "2017-08-21 00:00", end_date: "2017-08-30", progress: 0},
   ];
  return tasks_;
}
  constructor() { 

  }
  
}

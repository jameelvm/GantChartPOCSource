import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import "dhtmlx-gantt";
import { TaskService } from "../task.service";
import { LinkService } from "../link.service";


@Component({
  encapsulation: ViewEncapsulation.None,
  selector: 'app-gantt',
  templateUrl: './gantt.component.html',
  styleUrls: ['./gantt.component.scss'],
  styles: [
    `
    :host{
        display: block;
        height: 600px;
        position: relative;
        width: 100%;
    }
`],
  providers: [TaskService, LinkService],
  template: `<div #gantt_here class='gantt-chart'></div>`,
})
export class GanttComponent implements OnInit {
  @ViewChild("gantt_here", { static: true }) ganttContainer: ElementRef;
  html = 'Hello World';
  constructor(private taskService: TaskService, private linkService: LinkService) { }

  ngOnInit() {
    gantt.config.xml_date = "%Y-%m-%d %H:%i";
    //this.removeProgressText();
    this.disableProgressDrag();
    var resourceConfig = {
    };
    
gantt.config.open_tree_initially = false;
  gantt.init(this.ganttContainer.nativeElement);
    Promise.all([this.taskService.get()])
      .then(([data]) => {
        var childCount ;
        data.filter((t) => typeof (t.parent) == "undefined").forEach((t) => {
         childCount = data.filter((c) => c.parent == t.id).length;
          if(childCount==0){
            childCount=1;
          }
        });
       
  
      
        gantt.parse({ data });

        Promise.all([this.taskService.getTaskCount()]).then(([response])=>{
        this.setMilestoneCount(response);
        gantt.render();
        });
      // //   gantt.addTaskLayer(function draw_deadline(task) {
      // //     // if (task.deadline) {
      // //       //var wrapper = document.createElement('div');
      // //      // wrapper.className = 'form-group';
      // //         var el = document.createElement('div');
      // //         el.className = 'deadline';
            
      // //         var sizes = gantt.getTaskPosition(task, task.end_date,task.start_date);
       
      // //         el.style.left = sizes.left + 'px';
      // //         el.style.top = sizes.top + 'px';
      // //         el.innerText =childCount;
      // //         //wrapper.insertAdjacentElement('afterbegin', el);
      // //         el.setAttribute('title', gantt.templates.task_date(task.end_date));
      // //         return el;
      // //     // }
      // //     return false;
      // // });
        
       
      });


      

  }

  setMilestoneCount(response: any) {
    let _self = this;
    let mileStoneitem = [];
    gantt.addTaskLayer(function draw_deadline(task) {
        var wrapper = document.createElement('div');
        wrapper.className = 'form-group';
        mileStoneitem = response.filter((element) => element.id == task.id);
        if (mileStoneitem.length > 0) {
          mileStoneitem.forEach(item => {
              var el = document.createElement('div');
              el.className = 'deadline';
              var sizes = gantt.getTaskPosition(task, new Date(item.end_date), task.start_date);
              el.style.left = sizes.left + 'px';
              el.style.top = sizes.top + 'px';
                el.innerText = item.childCount;
              wrapper.insertAdjacentElement('afterbegin', el);
          });
          return wrapper;
        }
     
    });
  }
  removeProgressText() {
    gantt.templates.task_text = function (start, end, task) {
        return '';
    };
}
  disableProgressDrag() {
    gantt.attachEvent('onBeforeTaskDrag', function (id, mode, e) {
        return false;
    });
}
}

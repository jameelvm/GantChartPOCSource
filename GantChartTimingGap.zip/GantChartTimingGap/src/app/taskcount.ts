export class TaskCount {
    id: number;
    end_date: string;
    childCount:number;
}